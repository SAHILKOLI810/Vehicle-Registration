<?php
    echo 'Thanku'

?>
